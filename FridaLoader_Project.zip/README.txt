# Frida Loader Xposed Module Project

This is a complete Android Studio project template for building an Xposed module that loads Frida Gadget.

## Instructions

1. **Get the Gadget:**
   - Go to: https://github.com/frida/frida/releases
   - Download `frida-gadget-x.x.x-android-arm64.so.xz`
   - Extract it.
   - Rename the .so file to `libfrida-gadget.so`.

2. **Place the File:**
   - Copy `libfrida-gadget.so` into the folder:
     `FridaLoader/app/src/main/jniLibs/arm64-v8a/`
   - (Delete the PLACEHOLDER.txt file if you want, though it doesn't hurt).

3. **Build:**
   - Open this `FridaLoader` folder in **Android Studio**.
   - Wait for Gradle sync to finish.
   - Go to `Build > Build Bundle(s) / APK(s) > Build APK(s)`.

4. **Use with LSPatch:**
   - Copy the generated APK (usually in `app/build/outputs/apk/debug/app-debug.apk`) to your phone.
   - Open **LSPatch** app.
   - Select **Snapchat** (or your target app).
   - Select **Embed Modules**.
   - Choose your `app-debug.apk`.
   - Start Patch.
   - Install the patched Snapchat.

5. **Verify:**
   - Run `adb logcat -s FridaLoader` to see the logs.
   - Run `frida -U -N com.snapchat.android` (or just `frida -U Gadget`) to connect.